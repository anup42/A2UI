package com.samsung.genuicraft

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardColors
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

object GenUiTokens {
    val RadiusSm = 8.dp
    val RadiusMd = 12.dp
    val RadiusLg = 22.dp
    val RadiusXl = 26.dp
    val RadiusPill = 100.dp

    val BorderSm = 0.5.dp
    val BorderMd = 1.dp
    val BorderLg = 2.dp

    val ElevationSm = 0.dp
    val ElevationMd = 0.dp
    val ElevationLg = 0.dp
    val ElevationXl = 0.dp
}

enum class GenUiCardTone {
    Neutral,
    Primary,
    Positive,
    Warning,
    Error
}

private val LightScheme: ColorScheme = lightColorScheme(
    primary = Color(0xFF387AFF),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF2E65D4),
    onSecondary = Color(0xFFFFFFFF),
    tertiary = Color(0xFFE65B17),
    onTertiary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD6FFEB),
    onSecondaryContainer = Color(0xFF074225),
    tertiaryContainer = Color(0xFFFFEDDA),
    onTertiaryContainer = Color(0xFF4D1E08),
    background = Color(0xFFF1F1F3),
    onBackground = Color(0xFF010102),
    surface = Color(0xFFFCFCFF),
    onSurface = Color(0xFF252528),
    surfaceVariant = Color(0xFFE9E9EC),
    onSurfaceVariant = Color(0xFF4D4D52),
    surfaceTint = Color(0xFF387AFF),
    outline = Color(0xFFB7B7BB),
    outlineVariant = Color(0xFFE4E4E7),
    error = Color(0xFFD93E36),
    onError = Color(0xFFFFFFFF),
    scrim = Color(0x99000000)
)

private val DarkScheme: ColorScheme = darkColorScheme(
    primary = Color(0xFF387AFF),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF578FFF),
    onSecondary = Color(0xFFFFFFFF),
    tertiary = Color(0xFFFF8249),
    onTertiary = Color(0xFF010102),
    secondaryContainer = Color(0xFF0C7542),
    onSecondaryContainer = Color(0xFFB0FFD9),
    tertiaryContainer = Color(0xFF993D0F),
    onTertiaryContainer = Color(0xFFFFD3BD),
    background = Color(0xFF010102),
    onBackground = Color(0xFFFCFCFF),
    surface = Color(0xFF17171A),
    onSurface = Color(0xFFE9E9EC),
    surfaceVariant = Color(0xFF17171A),
    onSurfaceVariant = Color(0xFFB7B7BB),
    surfaceTint = Color(0xFF578FFF),
    outline = Color(0xFF636368),
    outlineVariant = Color(0xFF3A3A3D),
    error = Color(0xFFD93E36),
    onError = Color(0xFFFFFFFF),
    scrim = Color(0x99000000)
)

private val GenUiTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W700,
        fontSize = 34.sp,
        lineHeight = 43.sp,
        letterSpacing = 0.sp
    ),
    displayMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 30.sp,
        letterSpacing = 0.sp
    ),
    displaySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 26.sp,
        letterSpacing = 0.sp
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W700,
        fontSize = 21.sp,
        letterSpacing = 0.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 21.sp,
        letterSpacing = 0.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 19.sp,
        letterSpacing = 0.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W700,
        fontSize = 19.sp,
        letterSpacing = 0.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 17.sp,
        letterSpacing = 0.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 15.sp,
        letterSpacing = 0.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W400,
        fontSize = 17.sp,
        letterSpacing = 0.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W400,
        fontSize = 15.sp,
        letterSpacing = 0.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W400,
        fontSize = 14.sp,
        letterSpacing = 0.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 17.sp,
        letterSpacing = 0.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W600,
        fontSize = 13.sp,
        letterSpacing = 0.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W400,
        fontSize = 11.sp,
        letterSpacing = 0.sp
    )
)

private val GenUiShapes = Shapes(
    small = RoundedCornerShape(GenUiTokens.RadiusMd),
    medium = RoundedCornerShape(GenUiTokens.RadiusLg),
    large = RoundedCornerShape(GenUiTokens.RadiusXl)
)

@Composable
fun genUiBackgroundBrush(): Brush {
    val dark = isSystemInDarkTheme()
    val scheme = MaterialTheme.colorScheme
    val backgroundTransparency = InferenceBackendSettings.getRenderBackgroundTransparency(LocalContext.current)
    val tintScale = (1f - (backgroundTransparency * 0.72f)).coerceIn(0.62f, 1f)
    val top = scheme.surfaceContainerLowest.copy(alpha = (if (dark) 0.20f else 0.22f) * tintScale)
    val midPrimary = lerp(
        scheme.surfaceContainerLow,
        scheme.primaryContainer,
        if (dark) 0.24f else 0.18f
    )
    val midAccent = lerp(
        scheme.surfaceContainer,
        scheme.tertiaryContainer,
        if (dark) 0.22f else 0.16f
    )
    return Brush.verticalGradient(
        colors = listOf(
            top,
            midPrimary.copy(alpha = (if (dark) 0.34f else 0.34f) * tintScale),
            midAccent.copy(alpha = (if (dark) 0.30f else 0.30f) * tintScale),
            top
        )
    )
}

@Composable
fun genUiScreenOverlayColor(): Color {
    val overlayOpacity = InferenceBackendSettings.getRenderBackgroundOpacity(LocalContext.current)
    return MaterialTheme.colorScheme.background.copy(alpha = overlayOpacity)
}

@Composable
fun genUiCardContainerColor(tone: GenUiCardTone = GenUiCardTone.Neutral): Color {
    val dark = isSystemInDarkTheme()
    val scheme = MaterialTheme.colorScheme
    val userOpacity = InferenceBackendSettings.getRenderCardOpacity(LocalContext.current)
    val tokenColor = when (tone) {
        GenUiCardTone.Neutral -> scheme.surfaceContainerLow
        GenUiCardTone.Primary -> scheme.primaryContainer
        GenUiCardTone.Positive -> scheme.secondaryContainer
        GenUiCardTone.Warning -> scheme.tertiaryContainer
        GenUiCardTone.Error -> scheme.errorContainer
    }
    val glassBase = lerp(tokenColor, scheme.surfaceContainerHighest, if (dark) 0.26f else 0.42f)
    val blended = lerp(glassBase, scheme.primaryContainer, if (dark) 0.10f else 0.16f)
    val alpha = when (tone) {
        GenUiCardTone.Neutral -> userOpacity
        GenUiCardTone.Primary -> userOpacity + 0.02f
        GenUiCardTone.Positive -> userOpacity + 0.02f
        GenUiCardTone.Warning -> userOpacity + 0.02f
        GenUiCardTone.Error -> userOpacity + 0.03f
    }
    return blended.copy(alpha = alpha.coerceIn(0.60f, 0.96f))
}

@Composable
fun genUiCardColors(tone: GenUiCardTone = GenUiCardTone.Neutral): CardColors {
    return CardDefaults.cardColors(containerColor = genUiCardContainerColor(tone))
}

@Composable
fun genUiCardBorderColor(): Color {
    val dark = isSystemInDarkTheme()
    return MaterialTheme.colorScheme.outlineVariant.copy(alpha = if (dark) 0.72f else 0.62f)
}

@Composable
fun genUiMediaFrameBorderColor(): Color {
    // Keep media borders neutral so dynamic palettes do not produce warm/red-looking image frames.
    return if (isSystemInDarkTheme()) Color(0xFF636368) else Color(0xFFB7B7BB)
}

@Composable
fun genUiTableContainerColor(): Color {
    val dark = isSystemInDarkTheme()
    val scheme = MaterialTheme.colorScheme
    val userOpacity = InferenceBackendSettings.getRenderCardOpacity(LocalContext.current)
    val mixed = lerp(scheme.surfaceContainerLow, scheme.surfaceContainerHighest, if (dark) 0.24f else 0.40f)
    return mixed.copy(alpha = userOpacity.coerceIn(0.60f, 0.96f))
}

@Composable
fun genUiChromeContainerColor(): Color {
    val dark = isSystemInDarkTheme()
    val scheme = MaterialTheme.colorScheme
    val userOpacity = InferenceBackendSettings.getRenderCardOpacity(LocalContext.current)
    val base = lerp(
        scheme.primaryContainer,
        scheme.surfaceContainerLow,
        if (dark) 0.46f else 0.34f
    )
    val alpha = (userOpacity - if (dark) 0.16f else 0.18f).coerceIn(0.44f, 0.78f)
    return base.copy(alpha = alpha)
}

@Composable
fun genUiTopBarContainerColor(): Color {
    return genUiChromeContainerColor()
}

@Composable
fun GenUiCraftTheme(content: @Composable () -> Unit) {
    val darkTheme = isSystemInDarkTheme()
    val view = LocalView.current
    val baseScheme = if (darkTheme) {
        DarkScheme
    } else {
        LightScheme
    }
    val colorScheme = baseScheme.copy(
        // Keep text/readability stable on translucent windows in Samsung One UI by
        // avoiding semi-transparent text colors that can produce pale text bounding boxes.
        onSurfaceVariant = baseScheme.onSurfaceVariant.copy(alpha = 1f),
        outline = baseScheme.outline.copy(alpha = 1f),
        outlineVariant = baseScheme.outlineVariant.copy(alpha = 1f)
    )

    SideEffect {
        val window = view.context.findActivity()?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        controller.isAppearanceLightStatusBars = !darkTheme
        controller.isAppearanceLightNavigationBars = !darkTheme
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = GenUiTypography,
        shapes = GenUiShapes,
        content = content
    )
}

private tailrec fun Context.findActivity(): Activity? {
    return when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }
}
