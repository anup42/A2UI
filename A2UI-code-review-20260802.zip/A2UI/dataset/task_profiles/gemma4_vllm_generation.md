# Gemma4 31B vLLM Dataset Generation

This profile runs A2UI dataset Stage 1, Stage 2, and Stage 3 against a local
Gemma4 31B model served by vLLM from a normal Python virtualenv. It does not
require Docker, Apptainer, or Singularity.

## Target Machine Notes

The latest device-camera capture showed:

- Runtime available: `singularity`, but this workflow does not use it
- NVIDIA driver: `580.159.03`
- CUDA reported by `nvidia-smi`: `13.0`
- GPUs visible: at least four `NVIDIA RTX 6000 Ada`
- GPU memory visible: `49140 MiB` per GPU

## Model Folder Layout

Set `GEMMA4_MODEL_ROOT` to the parent folder that contains both checkpoints:

```text
<GEMMA4_MODEL_ROOT>/
  gemma-4-31B-it/
  gemma-4-31B-it-assistant/
```

Equivalent names like `gemma-4-31b-it`, `google--gemma-4-31B-it`, and
`gemma4-31b-it-assistant` are also auto-detected. If your folder names differ,
set `GEMMA4_MODEL_PATH` and `GEMMA4_ASSISTANT_MODEL_PATH` directly.

## Create Python Environment

```bash
cd /path/to/A2UI

export GEMMA4_MODEL_ROOT=/path/to/parent/folder
export PYTHON_BIN=python3.12

bash dataset/scripts/setup_gemma4_vllm_python_env.sh
source gemma4_vllm_env/activate_gemma4_vllm.sh
```

The setup script defaults to a prebuilt nightly vLLM wheel and does not require
speculative decoding. This avoids local vLLM/CUDA source builds on the target
machine:

```bash
export A2UI_VLLM_INSTALL_MODE=nightly
export A2UI_REQUIRE_SPECULATIVE=0
export GEMMA4_SPECULATIVE_MODE=off
```

Only use source mode if you specifically need the Gemma4-special speculative
vLLM ref:

```text
9b4e83934d895b5f6e488411cd46c8d0915115a1
```

```bash
export A2UI_VLLM_INSTALL_MODE=source
export A2UI_REQUIRE_SPECULATIVE=1
export VLLM_SOURCE_REF=9b4e83934d895b5f6e488411cd46c8d0915115a1
export PYTORCH_INDEX_URL=https://download.pytorch.org/whl/cu130
export A2UI_TORCH_BACKEND=cu130
bash dataset/scripts/setup_gemma4_vllm_python_env.sh
```

The special vLLM source ref requires a matching PyTorch C++ ABI. The setup
script defaults to a clean reinstall of the vLLM stack and pins the same Torch
family used in the Docker script:

```bash
export A2UI_CLEAN_VLLM_STACK=1
export TORCH_VERSION=2.11.0
export TORCHVISION_VERSION=0.26.0
export TORCHAUDIO_VERSION=2.11.0
bash dataset/scripts/setup_gemma4_vllm_python_env.sh
```

Use this when you see an import error from `vllm/_C.abi3.so` with an undefined
`torch::jit` symbol. That error means vLLM and PyTorch were installed from
incompatible builds.

The setup script defaults to aggressive SSL bypass because the target machines
have certificate interception issues:

```bash
export A2UI_DISABLE_SSL_VERIFY=1
```

If the machine has working certificates, disable it:

```bash
export A2UI_DISABLE_SSL_VERIFY=0
```

If vLLM fails with missing CUDA runtime libraries, rerun the setup script. The
script installs CUDA 13.0 runtime/NVCC Python wheels by default to match the
target CUDA 13.0/cu130 stack:

```bash
export CUDA_RUNTIME_PACKAGE=nvidia-cuda-runtime==13.0.96
export CUDA_NVCC_PACKAGE=nvidia-cuda-nvcc==13.0.88
bash dataset/scripts/setup_gemma4_vllm_python_env.sh
```

If vLLM fails inside `flashinfer/jit/cpp_ext.py` with `ninja returned non-zero
exit status 127`, the FlashInfer sampler is enabled but the JIT toolchain is
incomplete. Rerun setup:

```bash
bash dataset/scripts/setup_gemma4_vllm_python_env.sh
```

The setup script keeps FlashInfer sampler enabled by default and installs:

- `flashinfer-python`
- `flashinfer-cubin`
- `flashinfer-jit-cache` from `https://flashinfer.ai/whl/${FLASHINFER_CUDA_TAG}`
- `ninja`
- `cmake`
- CUDA 13.0 runtime and NVCC Python wheels

Defaults:

```bash
export VLLM_USE_FLASHINFER_SAMPLER=1
export VLLM_HAS_FLASHINFER_CUBIN=1
export FLASHINFER_CUDA_TAG=cu130
```

Use another `FLASHINFER_CUDA_TAG` only if you intentionally switch the
PyTorch/vLLM stack away from CUDA 13.0/cu130.

## Start vLLM

Non-reasoning mode without speculative decoding:

```bash
source gemma4_vllm_env/activate_gemma4_vllm.sh

export GEMMA4_MODEL_ROOT=/path/to/parent/folder
export GEMMA4_ENABLE_REASONING=0
export GEMMA4_SPECULATIVE_MODE=off
export VLLM_MAX_MODEL_LEN=8192
export VLLM_MAX_NUM_BATCHED_TOKENS=8192
export VLLM_GPU_MEMORY_UTILIZATION=0.90

bash dataset/scripts/run_gemma4_vllm_python.sh
```

Gemma4 may fail startup with:

```text
Chunked MM input disabled but max_tokens_per_mm_item (...) is larger than max_num_batched_tokens (...)
```

The launcher sets `--max-num-batched-tokens 8192` by default to keep it above
Gemma4's multimodal item budget.

Reasoning/thinking mode:

```bash
source gemma4_vllm_env/activate_gemma4_vllm.sh

export GEMMA4_MODEL_ROOT=/path/to/parent/folder
export GEMMA4_ENABLE_REASONING=1
export LOCAL_VLLM_ENABLE_THINKING=1
export LOCAL_VLLM_STRIP_THINKING=1

bash dataset/scripts/run_gemma4_vllm_python.sh
```

To enable speculative decoding after base serving works:

```bash
export GEMMA4_SPECULATIVE_MODE=draft
export GEMMA4_REQUIRE_SPECULATIVE=1
export GEMMA4_SPECULATIVE_TOKENS=4
```

The vLLM Gemma4 recipe uses the assistant checkpoint with
`--speculative-config '{"model": "...assistant", "num_speculative_tokens": 4}'`
and uses `--reasoning-parser gemma4` for thinking mode. The launcher checks
that these flags exist before starting.

## Run Dataset Stages

With the server already running:

```bash
source gemma4_vllm_env/activate_gemma4_vllm.sh

export RUN_ID=dataset_gemma4_31b_vllm_v0
export GEMMA4_ENABLE_REASONING=0

bash dataset/scripts/run_gemma4_dataset_stages.sh
```

Run stages one by one:

```bash
STAGE=1 RUN_ID=dataset_gemma4_31b_vllm_v0 bash dataset/scripts/run_gemma4_dataset_stages.sh
STAGE=2 RUN_ID=dataset_gemma4_31b_vllm_v0 bash dataset/scripts/run_gemma4_dataset_stages.sh
STAGE=3 RUN_ID=dataset_gemma4_31b_vllm_v0 STAGE3_BATCH_SIZE=1 bash dataset/scripts/run_gemma4_dataset_stages.sh
```

Single-terminal 50-sample smoke run:

```bash
source gemma4_vllm_env/activate_gemma4_vllm.sh

export GEMMA4_MODEL_ROOT=/path/to/parent/folder
export RUN_ID=dataset_gemma4_31b_vllm_50
export TARGET_COUNT=50
export GEMMA4_ENABLE_REASONING=0
export GEMMA4_SPECULATIVE_MODE=off

bash dataset/scripts/run_gemma4_stage123_50_python.sh
```

## Readiness Check

```bash
curl -fsS http://127.0.0.1:8000/v1/models
```

If the call succeeds, the dataset stage scripts can use the local endpoint.
